import uprop2

old_figure = None

def cracked_figure(self, licdict):
    licence = old_figure(self, licdict)
    licence['concurrent_connections'] = 1024
    return licence


for x in dir(uprop2):
    if x[:2] == '__':
        continue
    if x == 'UsageProperties':
        exec 'old_figure = uprop2.UsageProperties.figure'
        exec 'uprop2.UsageProperties.figure = cracked_figure'
    exec '%s = uprop2.%s' % (x, x)

